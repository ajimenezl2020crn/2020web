<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/style.css" />

  </head>
  <body>

<div id="contenidor">


    <div id="inici">
      <h1>cars<b>and</b>films</h1>
      <div id="animacio">
      </div>
    </div>


    <div class="cotxes" id="cotxe1" clas="grid_4">
      <img src="img/small/small_pulp.jpg">
      <p>Pulp Fiction</p>
    </div>

    <div class="cotxes" id="cotxe2" clas="grid_4">
      <img src="img/small/small_taxi.jpg">
      <p>Taxi Driver</p>
    </div>

    <div class="cotxes" id="cotxe3" clas="grid_4">
      <img src="img/small/small_bond.jpg">
      <p>Goldfinger</p>
    </div>

    <div class="cotxes" id="cotxe4" clas="grid_4">
      <img src="img/small/small_ghost.jpg">
      <p>Ghost Busters</p>
    </div>

    <div class="cotxes" id="cotxe5">
      <img src="img/small/small_bean.jpg">
      <p>Mr. Bean</p>
    </div>

    <div class="cotxes" id="cotxe6">
      <img src="img/small/small_back.jpg">
      <p>Back to the Future</p>
    </div>

    <div class="cotxes" id="cotxe7">
      <img src="img/small/small_rider.jpg">
      <p>Knight Rider</p>
    </div>

    <div class="cotxes" id="cotxe8">
      <img src="img/small/small_team.jpg">
      <p>The A-Team</p>
    </div>


    <div class="cotxes" id="cotxe9">
      <img src="img/small/small_break.jpg">
      <p>Breaking Bad</p>
    </div>

    <div id="footer">
      <img src="img/logo_carsandfilms.png">


    </div>

  </div>


  </body>
</html>
